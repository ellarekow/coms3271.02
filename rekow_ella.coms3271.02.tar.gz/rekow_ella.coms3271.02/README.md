# coms3271.02

This gengerates the entire 399x399 map. There is movement by utalizing n, s, w, and e. The fly option is somewhat buggy, however the rest should generate cleanly. 